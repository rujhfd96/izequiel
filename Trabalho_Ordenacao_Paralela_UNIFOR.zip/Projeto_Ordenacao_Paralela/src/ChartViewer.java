import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;

/** Extra: grafico dinamico Swing a partir do resumo estatistico CSV. */
public final class ChartViewer {
    record Point(int size,double ms) {}
    record Observation(int cores,String algorithm,String distribution,int size,String mode,int threads,double median) {}
    static List<Observation> read(Path path)throws IOException{
        List<Observation> list=new ArrayList<>();
        try(BufferedReader br=Files.newBufferedReader(path)){
            String head=br.readLine();
            if(head==null || !head.contains("median_ms"))throw new IOException("CSV resumo incorreto");
            String line;
            while((line=br.readLine())!=null){
                String[] t=line.split(",");
                if(t.length<9)continue;
                list.add(new Observation(Integer.parseInt(t[0]),t[1],t[2],Integer.parseInt(t[3]),t[4],Integer.parseInt(t[5]),Double.parseDouble(t[8])));
            }
        }
        return list;
    }
    public static void main(String[] args)throws Exception{
        Path csv=Path.of(args.length>0?args[0]:"resultados/resumo_estatistico.csv");
        List<Observation> entries=read(csv);
        if(entries.isEmpty())throw new IllegalArgumentException("CSV vazio: "+csv);
        SwingUtilities.invokeLater(()->{
            JFrame f=new JFrame("Comparador de Ordenacao - Graficos Dinamicos");
            f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT,12,10));
            JComboBox<String> algo=new JComboBox<>(new String[]{"quick","merge","counting","insertion"});
            JComboBox<String> dist=new JComboBox<>(new String[]{"random","sorted","reversed","few_unique"});
            Integer[] possible=entries.stream().map(Observation::cores).distinct().sorted().toArray(Integer[]::new);
            JComboBox<Integer> cores=new JComboBox<>(possible);cores.setSelectedIndex(possible.length-1);
            top.add(new JLabel("Algoritmo:"));top.add(algo);top.add(new JLabel("Dados:"));top.add(dist);
            top.add(new JLabel("CPUs permitidas:"));top.add(cores);
            Graph graph=new Graph(entries,algo,dist,cores);graph.setPreferredSize(new Dimension(980,580));
            algo.addActionListener(e->graph.repaint());dist.addActionListener(e->graph.repaint());cores.addActionListener(e->graph.repaint());
            f.add(top,BorderLayout.NORTH);f.add(graph,BorderLayout.CENTER);
            f.pack();f.setLocationRelativeTo(null);f.setVisible(true);
        });
    }
    private static final class Graph extends JPanel{
        private final List<Observation> rows;
        private final JComboBox<String> algorithm, distribution;
        private final JComboBox<Integer> cores;
        Graph(List<Observation> r,JComboBox<String> a,JComboBox<String>d,JComboBox<Integer>c){rows=r;algorithm=a;distribution=d;cores=c;setBackground(Color.WHITE);}
        @Override protected void paintComponent(Graphics gg){
            super.paintComponent(gg);
            Graphics2D g=(Graphics2D)gg.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            int w=getWidth(),h=getHeight(),left=95,right=40,top=55,bottom=92;
            int xw=w-left-right,yh=h-top-bottom;
            List<List<Point>> series=new ArrayList<>();
            String[] labels={"Serial","1 thread","2 threads","4 threads"};
            for(int z=0;z<4;z++){
                List<Point> pts=new ArrayList<>();
                for(Observation o:rows)if(o.cores()==(Integer)cores.getSelectedItem() && o.algorithm().equals(algorithm.getSelectedItem()) && o.distribution().equals(distribution.getSelectedItem()) && (z==0?o.mode().equals("serial"):(o.mode().equals("parallel") && o.threads()==(z==1?1:z==2?2:4))))pts.add(new Point(o.size(),o.median()));
                pts.sort(Comparator.comparingInt(Point::size));series.add(pts);
            }
            int maxX=1;double maxY=0;
            for(List<Point> pts:series)for(Point p:pts){maxX=Math.max(maxX,p.size());maxY=Math.max(maxY,p.ms());}
            maxY=Math.max(0.01,maxY*1.08);
            g.setFont(new Font("SansSerif",Font.BOLD,17));g.setColor(new Color(20,40,65));g.drawString("Tempo mediano de ordenacao (ms)",left,28);
            g.setFont(new Font("SansSerif",Font.PLAIN,12));
            for(int i=0;i<=5;i++){
                int py=top+yh-i*yh/5;g.setColor(new Color(230,235,240));g.drawLine(left,py,left+xw,py);
                g.setColor(Color.DARK_GRAY);g.drawString(String.format(Locale.US,"%.3f",maxY*i/5),15,py+4);
            }
            g.setColor(Color.GRAY);g.drawLine(left,top,left,top+yh);g.drawLine(left,top+yh,left+xw,top+yh);
            for(int i=0;i<=5;i++){
                int px=left+i*xw/5;
                g.drawString(String.format(Locale.US,"%,d",(long)maxX*i/5),px-15,top+yh+20);
            }
            Color[] palette={new Color(35,70,100),new Color(33,150,110),new Color(213,122,40),new Color(139,75,169)};
            for(int s=0;s<series.size();s++){
                g.setColor(palette[s]);g.setStroke(new BasicStroke(2.5f));
                Point last=null;
                for(Point p:series.get(s)){
                    int x=left+(int)(p.size()/(double)maxX*xw);
                    int y=top+yh-(int)(p.ms()/maxY*yh);
                    if(last!=null){
                        int lx=left+(int)(last.size()/(double)maxX*xw);
                        int ly=top+yh-(int)(last.ms()/maxY*yh);
                        g.draw(new Line2D.Double(lx,ly,x,y));
                    }
                    g.fill(new Ellipse2D.Double(x-4,y-4,8,8));last=p;
                }
                int lx=left+15+s*170,ly=h-35;
                g.fillRect(lx,ly-10,23,4);g.setColor(Color.DARK_GRAY);g.drawString(labels[s],lx+30,ly-4);
            }
            g.setColor(Color.GRAY);g.drawString("Tamanho do vetor (n)",left+xw/2-65,h-57);
            g.dispose();
        }
    }
}
