#!/usr/bin/env python3
"""Gera o artigo a partir do modelo fornecido pela disciplina e dos resultados CSV."""
import csv
from pathlib import Path
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
TEMPLATE=Path('/mnt/data/Modelo-Artigo(1).docx')
TARGET=ROOT/'Relatorio_Ordenacao_Paralela_UNIFOR.docx'
ROWS=list(csv.DictReader(open(ROOT/'resultados/resumo_estatistico.csv',encoding='utf-8')))

def r(alg,n,cores=4,mode='parallel',t=4,dist='random'):
    found=[x for x in ROWS if x['algorithm']==alg and int(x['size'])==n and int(x['cores'])==cores and x['mode']==mode and int(x['threads'])==t and x['distribution']==dist]
    if len(found)!=1:raise ValueError((alg,n,cores,mode,t,dist))
    return found[0]
def fmt(x):return f'{float(x):.3f}'.replace('.',',')
def border(paragraph,fill='E7E7E7'):
    pp=paragraph._p.get_or_add_pPr()
    shd=OxmlElement('w:shd');shd.set(qn('w:fill'),fill);pp.append(shd)
    bdr=OxmlElement('w:pBdr');bt=OxmlElement('w:bottom');bt.set(qn('w:val'),'single');bt.set(qn('w:sz'),'6');bt.set(qn('w:color'),'595959');bdr.append(bt)
    tp=OxmlElement('w:top');tp.set(qn('w:val'),'single');tp.set(qn('w:sz'),'6');tp.set(qn('w:color'),'595959');bdr.append(tp);pp.append(bdr)
def shade_cell(cell,color='E9EDF2'):
    tcPr=cell._tc.get_or_add_tcPr();shd=OxmlElement('w:shd');shd.set(qn('w:fill'),color);tcPr.append(shd)
def no_split(row):
    trPr=row._tr.get_or_add_trPr();el=OxmlElement('w:cantSplit');trPr.append(el)

def p(text='',boldstart=None):
    par=d.add_paragraph(style='Normal')
    par.paragraph_format.first_line_indent=Cm(.55)
    par.paragraph_format.space_after=Pt(5)
    if boldstart and text.startswith(boldstart):
        a=par.add_run(boldstart);a.bold=True;par.add_run(text[len(boldstart):])
    else: par.add_run(text)
    return par

def heading(text):
    par=d.add_paragraph(style='Normal')
    par.paragraph_format.space_before=Pt(12);par.paragraph_format.space_after=Pt(7)
    par.paragraph_format.keep_with_next=True
    par.paragraph_format.first_line_indent=0
    par.paragraph_format.line_spacing=1.0
    run=par.add_run(text);run.bold=True;run.font.size=Pt(12)
    border(par)
    return par

def subheading(text):
    par=d.add_paragraph(style='Normal')
    par.paragraph_format.space_before=Pt(8);par.paragraph_format.space_after=Pt(4)
    par.paragraph_format.keep_with_next=True;par.paragraph_format.first_line_indent=0
    run=par.add_run(text);run.bold=True;run.font.size=Pt(11)
    return par

def table(headers,body,widths=None):
    t=d.add_table(rows=1, cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.style='Table Grid'
    for i,h in enumerate(headers):
        c=t.rows[0].cells[i];c.text=h;shade_cell(c,'E0E6EC');c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for rr in body:
        row=t.add_row();no_split(row)
        for i,val in enumerate(rr):row.cells[i].text=str(val)
    for i,row in enumerate(t.rows):
        for j,c in enumerate(row.cells):
            if widths and j<len(widths): c.width=Cm(widths[j])
            for par in c.paragraphs:
                par.paragraph_format.line_spacing=1.0;par.paragraph_format.space_after=Pt(1);par.paragraph_format.first_line_indent=0
                for run in par.runs:run.font.name='Arial';run.font.size=Pt(9)
                if i==0:
                    for run in par.runs:run.bold=True
    return t

def figure(name,caption):
    par=d.add_paragraph(style='Normal');par.paragraph_format.first_line_indent=0
    par.paragraph_format.space_before=Pt(3);par.paragraph_format.space_after=Pt(2)
    par.alignment=WD_ALIGN_PARAGRAPH.CENTER
    par.add_run().add_picture(str(ROOT/'graficos'/name),width=Cm(15.0))
    cap=d.add_paragraph(style='Normal');cap.paragraph_format.first_line_indent=0
    cap.paragraph_format.line_spacing=1.0;cap.paragraph_format.space_after=Pt(3)
    cap.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=cap.add_run(caption+' Fonte: elaboração própria com base nas medições reproduzíveis (2026).')
    run.italic=True;run.font.size=Pt(9)

# Abre o próprio arquivo de modelo e substitui apenas a área de conteúdo.
d=Document(TEMPLATE)
body=d._element.body
for item in list(body):
    if item.tag!=qn('w:sectPr'):body.remove(item)
section=d.sections[0];section.top_margin=Cm(2.0);section.bottom_margin=Cm(2.0)
section.left_margin=Cm(2.0);section.right_margin=Cm(2.0)
normal=d.styles['Normal'];normal.font.name='Arial';normal.font.size=Pt(11)
normal.paragraph_format.line_spacing=1.5
normal.paragraph_format.space_after=Pt(5)

# Cabecalho fiel ao template: logo e identificacao institucional.
ht=d.add_table(rows=1,cols=2);ht.autofit=False;ht.alignment=WD_TABLE_ALIGNMENT.CENTER
ht.columns[0].width=Cm(3.4);ht.columns[1].width=Cm(12.8)
logo=ht.cell(0,0).paragraphs[0];logo.paragraph_format.line_spacing=1.0
logo.add_run().add_picture(str(ROOT/'documentacao/logo_unifor_modelo.png'),width=Cm(3.0))
pinst=ht.cell(0,1).paragraphs[0];pinst.paragraph_format.line_spacing=1.0
for line in ['UNIVERSIDADE DE FORTALEZA','CENTRO DE CIÊNCIAS TECNOLÓGICAS','CURSO: CIÊNCIA DA COMPUTAÇÃO']:
    run=pinst.add_run(line);run.font.name='Arial';run.font.size=Pt(10)
    if line!='CURSO: CIÊNCIA DA COMPUTAÇÃO':pinst.add_run('\n')
# retira linhas da tabela de cabecalho
for cell in ht.rows[0].cells:
    tcPr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
    for s in ['top','left','bottom','right','insideH','insideV']:
        el=OxmlElement(f'w:{s}');el.set(qn('w:val'),'nil');borders.append(el)
    tcPr.append(borders)

title=d.add_paragraph();title.alignment=WD_ALIGN_PARAGRAPH.CENTER
title.paragraph_format.space_before=Pt(21);title.paragraph_format.space_after=Pt(14);title.paragraph_format.line_spacing=1.15
t=title.add_run('ANÁLISE DE DESEMPENHO DE ALGORITMOS DE ORDENAÇÃO EM AMBIENTES CONCORRENTES E PARALELOS: UM ESTUDO COMPARATIVO EM JAVA')
t.bold=True;t.font.name='Arial';t.font.size=Pt(14)
for s in ['Autor 1: [NOME COMPLETO DO PRIMEIRO INTEGRANTE]','Autor 2: [NOME COMPLETO DO SEGUNDO INTEGRANTE]']:
    x=d.add_paragraph(s);x.paragraph_format.first_line_indent=0;x.paragraph_format.space_after=Pt(0)
    for run in x.runs:run.italic=True;run.font.size=Pt(10)
d.add_paragraph('')
kw=d.add_paragraph();kw.paragraph_format.first_line_indent=0
kw.add_run('Palavras-chave: ').bold=True
kw.add_run('Ordenação. Programação paralela. Java. Análise de desempenho. Multicore.')

heading('Resumo')
p('Este estudo compara quatro algoritmos de ordenação — Quick Sort, Merge Sort, Counting Sort e Insertion Sort — nas modalidades sequencial e paralela, em linguagem Java. Foi desenvolvido um framework experimental com entradas aleatórias, ordenadas, invertidas e de baixa cardinalidade, variando o tamanho do vetor, o número de threads e a afinidade da CPU. A execução realizada em Linux com OpenJDK 21 produziu 4.320 medições válidas, distribuídas em 864 configurações com cinco amostras cada. Foram calculadas média, mediana, desvio-padrão, coeficiente de variação, speedup e eficiência, com exportação para CSV e visualização em gráficos estáticos e em Java Swing. Para vetores aleatórios de 300.000 elementos e quatro CPUs lógicas permitidas, Quick Sort e Merge Sort alcançaram speedups de 2,42 e 2,81, enquanto Counting Sort obteve 0,65, evidenciando custos de coordenação e redução. O Insertion Sort híbrido apresentou speedup de 6,44 para 20.000 elementos, mas esse resultado também decorre da alteração de complexidade introduzida pela intercalação de partições. Os resultados indicam que a eficiência depende da natureza dos dados, do algoritmo e dos custos de paralelização, além de demonstrar a necessidade de avaliar comparabilidade metodológica e variabilidade das medições.')

heading('Introdução')
p('A ordenação de dados é uma operação fundamental em sistemas computacionais, permitindo organizar conjuntos de elementos para consultas, indexação e processamento posterior. Embora o enunciado da atividade mencione “algoritmos de busca”, os métodos disponibilizados para escolha — Bubble Sort, Quick Sort, Merge Sort, Selection Sort, Counting Sort e Insertion Sort — pertencem à categoria de algoritmos de ordenação. Neste artigo adota-se a terminologia correta, sem modificar o objetivo experimental proposto.')
p('A arquitetura multicore permite executar tarefas simultâneas, mas o uso de múltiplas threads não garante menor tempo de execução. A divisão do problema, a criação e sincronização das tarefas, a disputa por memória e a fração sequencial impõem limitações à aceleração. Isso é compatível com o princípio de Amdahl (1967), segundo o qual o desempenho paralelo depende da porção efetivamente paralelizável do trabalho.')
p('Os algoritmos selecionados oferecem comportamentos distintos. Quick Sort utiliza partição recursiva e tem complexidade média O(n log n), embora possa atingir O(n²) no pior caso. Merge Sort divide e intercala segmentos, com tempo O(n log n) e memória auxiliar O(n). Counting Sort contabiliza frequências em um intervalo de valores inteiros e exige O(n + k), sendo k o tamanho desse intervalo. Insertion Sort é simples e eficiente para conjuntos pequenos ou quase ordenados, porém normalmente executa O(n²) comparações e deslocamentos (CORMEN et al., 2022; BLACK, 2020).')
p('O objetivo geral é implementar e comparar esses quatro métodos em Java, em condições sequenciais e paralelas, explorando entrada, tamanho, threads e CPUs lógicas disponíveis. Adicionalmente, busca-se documentar as limitações experimentais, disponibilizar resultados em CSV e oferecer visualização interativa para inspeção e futura reprodução.')

heading('Metodologia')
subheading('Ambiente computacional e organização do experimento')
p('O experimento principal foi executado em ambiente Linux x86-64, com OpenJDK 21, em contêiner compartilhado. A quantidade de CPUs lógicas efetivamente permitidas ao processo foi restringida usando taskset para 1, 2 ou 4 CPUs. Esse controle de afinidade não equivale a reservar exclusivamente os núcleos, pois a carga de outros processos e a cota de CPU do ambiente podem influenciar os resultados. A execução no Windows oferecida no projeto usa a opção ActiveProcessorCount, que altera a contagem visível à JVM, mas não reproduz o mesmo controle de afinidade.')
p('Foram implementados quatro cenários: random (valores pseudoaleatórios de 0 a n−1); sorted (ordenação crescente do mesmo conjunto aleatório); reversed (ordenação decrescente desse mesmo conjunto); e few_unique (valores em apenas 16 categorias). Cada configuração utiliza semente determinística e a mesma entrada para todos os modos e contagens de threads. Assim, mudanças de resultado não são atribuíveis a alterações arbitrárias nos dados.')
p('Para Quick Sort, Merge Sort e Counting Sort, os tamanhos foram n = 2.000, 10.000, 30.000, 100.000 e 300.000 elementos. Para Insertion Sort, utilizaram-se n = 2.000, 10.000 e 20.000, porque sua complexidade quadrática amplia fortemente o custo dos casos maiores. Foram avaliadas uma modalidade sequencial e modalidades paralelas com 1, 2 e 4 threads, repetidas para cada configuração de 1, 2 ou 4 CPUs permitidas. O total é de 864 combinações × 5 amostras = 4.320 observações verificadas.')
subheading('Implementações e paralelismo')
p('Quick Sort emprega pivot por mediana de três e partição em três vias, favorável à presença de chaves repetidas. Sua versão paralela divide intervalos independentes em tarefas Fork/Join; segmentos pequenos são resolvidos sequencialmente. Merge Sort utiliza vetor auxiliar compartilhado por posições não sobrepostas e cria tarefas recursivas para as metades, realizando a intercalação após ambas terminarem. Nos dois casos, o limiar para criar novas tarefas paralelas é de 16.384 elementos.')
p('Counting Sort sequencial encontra mínimo e máximo, preenche histograma e reescreve o vetor em ordem crescente. Na versão paralela, cada tarefa atualiza seu próprio histograma, eliminando concorrência nas contagens; em seguida ocorre a soma dos histogramas e a escrita final sequencial. A implementação limita k = máximo − mínimo + 1 a 5.000.000 posições, prevenindo alocações extremas de memória. O custo adicional é O(p · k) de histogramas auxiliares, para p tarefas, o que pode prejudicar o paralelismo.')
p('O Insertion Sort paralelo é explicitamente um algoritmo híbrido: cada tarefa executa Insertion Sort em uma partição e, após a ordenação local, segmentos são intercalados em rodadas. Sua execução difere da versão sequencial não apenas por threads, mas pela decomposição algorítmica; portanto, valores de speedup acima da quantidade de CPUs não devem ser interpretados como aceleração pura de uma mesma rotina de Insertion Sort.')
subheading('Coleta, validade e tratamento estatístico')
p('Cada combinação recebeu duas ou três iterações preliminares de aquecimento da JVM, seguidas de exatamente cinco amostras registradas. A medição com System.nanoTime() circunscreve somente o algoritmo: criação dos dados, clonagem do vetor e verificação de correção são executadas fora do cronômetro. As alocações inerentes a cada algoritmo e a criação de tarefas dentro da ordenação são, entretanto, contabilizadas. O ForkJoinPool é criado antes da medição e reutilizado durante a configuração.')
p('Todos os resultados foram comparados com Arrays.sort do Java; em caso de divergência, o executor interrompe a medição e não registra uma amostra inválida. Os arquivos CSV preservam o contexto da amostra, incluindo distribuição, tamanho, CPUs disponíveis, threads, repetição, tempo em nanossegundos, tempo em milissegundos, JVM, sistema operacional, semente e resultado da validação.')
p('Para cada grupo calculam-se média, mediana, desvio-padrão amostral, mínimo, máximo e coeficiente de variação (CV = 100 × desvio-padrão / média). O speedup é a razão entre a mediana do modo sequencial e a mediana do modo paralelo, sempre com o mesmo algoritmo, distribuição, tamanho e limite de CPUs; a eficiência é speedup dividido pelo número de threads. A mediana é privilegiada como medida robusta a variações esporádicas de tempo. As medições são exploratórias; testes formais de significância ou intervalos de confiança não foram estimados, uma vez que cinco amostras por configuração são o mínimo exigido e podem ser insuficientes para inferência populacional rigorosa.')

heading('Resultados e Discussão')
subheading('Comparação principal com quatro CPUs disponíveis')
p('A Tabela 1 resume o tempo mediano em milissegundos para entradas aleatórias, quatro CPUs lógicas disponíveis e quatro threads no modo paralelo. Os tamanhos considerados são os maiores previstos para cada algoritmo, permitindo observar a região de maior demanda computacional. Valores de speedup inferiores a 1 indicam perda de desempenho.')
main=[]
for alg,n,label in [('quick',300000,'Quick Sort'),('merge',300000,'Merge Sort'),('counting',300000,'Counting Sort'),('insertion',20000,'Insertion Sort (híbrido)')]:
    serial=r(alg,n,mode='serial',t=0);parallel=r(alg,n)
    main.append([label,f'{n:,}'.replace(',','.'),fmt(serial['median_ms']),fmt(parallel['median_ms']),fmt(parallel['speedup_vs_serial'])+'×'])
table(['Algoritmo','Elementos','Serial (ms)','Paralelo (ms)','Speedup'],main)
cpq=r('quick',300000);cpm=r('merge',300000);cpc=r('counting',300000);cpi=r('insertion',20000)
p(f'A implementação paralela de Merge Sort obteve o melhor speedup entre os três métodos de complexidade subquadrática examinados no maior vetor aleatório: {fmt(cpm["speedup_vs_serial"])}×. Quick Sort alcançou {fmt(cpq["speedup_vs_serial"])}×, enquanto Counting Sort registrou {fmt(cpc["speedup_vs_serial"])}×, isto é, a modalidade paralela foi mais lenta. O Insertion híbrido atingiu {fmt(cpi["speedup_vs_serial"])}× em n = 20.000, sem que isso autorize atribuir toda a diferença ao emprego de quatro CPUs.')
figure('tempos_quick.png','Figura 1 – Quick Sort: mediana de tempo por tamanho e quantidade de threads.')
figure('tempos_merge.png','Figura 2 – Merge Sort: mediana de tempo por tamanho e quantidade de threads.')
p('Nas Figuras 1 e 2, vetores pequenos frequentemente não justificam o custo da criação e coordenação das tarefas. Por exemplo, para Quick Sort com n = 2.000, quatro threads resultaram em speedup inferior a 1; no maior vetor, o custo da ordenação passa a ser suficiente para compensar a sobrecarga. Merge Sort apresenta comportamento semelhante, com ganhos mais consistentes para n maiores.')
figure('tempos_counting.png','Figura 3 – Counting Sort: mediana de tempo por tamanho e quantidade de threads.')
figure('tempos_insertion.png','Figura 4 – Insertion Sort híbrido: evolução do tempo por tamanho de vetor.')
p('A Figura 3 destaca a sensibilidade do Counting Sort ao intervalo de valores e aos custos de memória. O modo paralelo aloca histogramas por tarefa e realiza uma redução e reconstrução sequenciais. Desse modo, a redução de tempo na etapa de contagem pode ser superada pelo custo total. A Figura 4 mostra a superioridade do híbrido em vetores desordenados maiores, especialmente porque cada partição executa menos deslocamentos quadráticos e a etapa final combina blocos com intercalação.')
subheading('Efeito das CPUs lógicas disponíveis')
second=[]
for alg,n,label in [('quick',300000,'Quick'),('merge',300000,'Merge'),('counting',300000,'Counting'),('insertion',20000,'Insertion híbrido')]:
    for cores in [1,2,4]:
        row=r(alg,n,cores=cores)
        second.append([label,str(cores),fmt(row['median_ms']),fmt(row['speedup_vs_serial'])+'×'])
table(['Algoritmo','CPUs permitidas','Paralelo 4 threads (ms)','Speedup vs serial local'],second)
figure('cores_disponiveis.png','Figura 5 – Efeito da afinidade de 1, 2 e 4 CPUs permitidas no tempo.')
figure('speedup_por_threads.png','Figura 6 – Escalabilidade com aumento de threads; reta tracejada representa speedup ideal.')
p('A Tabela 2 e as Figuras 5 e 6 evidenciam que quatro threads sobre apenas uma CPU não equivalem a paralelismo real sobre quatro núcleos. No Quick Sort aleatório de 300.000 elementos, quatro threads sobre quatro CPUs reduziram a mediana para 8,699 ms, ante 22,586 ms com apenas uma CPU disponível. No Merge Sort os tempos correspondentes foram 11,968 ms e 29,301 ms. A comparação é limitada pelo ambiente compartilhado e não constitui garantia de aceleração linear em outros equipamentos.')
subheading('Natureza da entrada, dispersão e limites da inferência')
figure('distribuicoes.png','Figura 7 – Diferenças de tempo sequencial em quatro distribuições de entrada.')
p('A natureza dos dados altera o custo mesmo quando n permanece fixo. No Merge Sort sequencial de n = 300.000, a entrada já ordenada apresentou mediana de '+fmt(r('merge',300000,mode='serial',t=0,dist='sorted')['median_ms'])+' ms, contra '+fmt(r('merge',300000,mode='serial',t=0,dist='random')['median_ms'])+' ms na aleatória, porque a implementação evita intercalar segmentos quando já estão na ordem correta. Para Counting Sort, a distribuição com apenas 16 valores distintos reduz o tamanho do histograma e diminui substancialmente a operação. O Quick Sort com particionamento triplo também é favorecido pela baixa cardinalidade em relação à entrada aleatória.')
p('A variabilidade das medições impede generalizações excessivamente precisas. Por exemplo, o Counting Sort com quatro threads e apenas uma CPU apresentou CV de '+fmt(r('counting',300000,cores=1)['cv_percent'])+'%, sugerindo interferências da JVM, agendamento ou ambiente de teste. A mediana reduz, mas não elimina, esses efeitos. O experimento não controla frequência dinâmica da CPU, aquecimento térmico, coleta de lixo e carga de outros contêineres. Uma evolução metodológica relevante seria adotar JMH com múltiplas JVMs independentes, mais repetições e intervalos de confiança (OPENJDK, 2026).')

heading('Conclusão')
p('O projeto implementou quatro algoritmos de ordenação em Java, cada um com versões sequencial e paralela, e realizou 4.320 medições verificadas sob diferentes tamanhos, distribuições, quantidades de threads e limites de CPUs. O resultado cumpre os objetivos de construção de um framework de teste, coleta estatística, exportação para CSV, elaboração de gráficos e criação de visualização dinâmica com Swing.')
p('Para vetores aleatórios grandes, Quick Sort e Merge Sort se beneficiaram do uso de múltiplas CPUs, enquanto Counting Sort revelou que tarefas extras e histogramas replicados podem custar mais que a computação poupada. O Insertion Sort híbrido foi mais rápido em vetores grandes não ordenados, mas seus resultados não são comparáveis a um ganho puramente paralelo, dado que a estratégia muda o volume e a organização do trabalho algorítmico. Também foi constatado que o tamanho e a distribuição da entrada influenciam fortemente o desempenho, especialmente nos casos já ordenados e de baixa cardinalidade.')
p('Conclui-se que paralelização efetiva requer conhecer a complexidade do algoritmo, a granularidade das tarefas, os custos de memória e o perfil da entrada. Como trabalhos futuros recomendam-se experimentos com máquinas dedicadas, benchmarking por JMH, maior número de amostras e intervalos de confiança, avaliação de consumo de memória, comparação com Arrays.parallelSort e estudo separado de escalabilidade forte e fraca.')

heading('Referências')
for ref in [
 'AMDAHL, Gene M. Validity of the single processor approach to achieving large scale computing capabilities. In: AFIPS SPRING JOINT COMPUTER CONFERENCE, 1967. Proceedings [...]. New York: ACM, 1967. p. 483–485. DOI: https://doi.org/10.1145/1465482.1465560.',
 'BLACK, Paul E. DADS: The On-Line Dictionary of Algorithms and Data Structures. Gaithersburg: National Institute of Standards and Technology, 2020. (NISTIR 8318). Disponível em: https://doi.org/10.6028/NIST.IR.8318. Acesso em: 29 out. 2026.',
 'CORMEN, Thomas H. et al. Introduction to Algorithms. 4. ed. Cambridge, MA: MIT Press, 2022.',
 'OPENJDK. Java Microbenchmark Harness (JMH). [S. l.]: OpenJDK, 2026. Disponível em: https://github.com/openjdk/jmh. Acesso em: 29 out. 2026.',
 'ORACLE. Class ForkJoinPool: Java Platform, Standard Edition 21. [S. l.]: Oracle, 2026. Disponível em: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/ForkJoinPool.html. Acesso em: 29 out. 2026.',
 'ORACLE. Class System: Java Platform, Standard Edition 21. [S. l.]: Oracle, 2026. Disponível em: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/System.html. Acesso em: 29 out. 2026.'
]:
    x=d.add_paragraph(ref);x.paragraph_format.first_line_indent=0;x.paragraph_format.line_spacing=1.0;x.paragraph_format.space_after=Pt(8)

d.add_page_break()
heading('Anexos – Implementações e reprodutibilidade')
subheading('Anexo A – Código-fonte')
p('Os códigos completos estão no projeto anexado, especialmente em src/SortingAlgorithms.java (implementações), src/ExperimentRunner.java (benchmark e exportação CSV), src/SelfTest.java (teste automatizado), src/ChartViewer.java (gráfico dinâmico Swing), scripts/analyze.py (análise estatística) e scripts/run_linux.sh (reprodução com afinidade de CPU). O README.md fornece as instruções de compilação e execução para Linux e Windows.')
subheading('Anexo B – Arquivos de medição')
p('O arquivo resultados/resultados_brutos.csv contém as 4.320 observações originais, com registros de tempo e parâmetros; resultados/resumo_estatistico.csv reúne 864 grupos agregados e suas estatísticas; graficos/ reúne as sete figuras. Os arquivos foram gerados pela execução efetiva do código Java e não por simulação de tempos.')
subheading('Anexo C – Link do GitHub')
end=p('LINK DO REPOSITÓRIO: [INSERIR A URL REAL DO REPOSITÓRIO APÓS PUBLICAR O PROJETO NO GITHUB].')
end.runs[0].bold=True
p('Os arquivos foram preparados localmente, mas ainda não foram publicados em um repositório remoto. Antes da entrega do artigo, os autores devem publicar o conteúdo e substituir o marcador acima pelo endereço público ou acessível ao docente. O arquivo README.md apresenta as instruções git necessárias.')

subheading('Anexo D – Trechos representativos do código')
p('Trecho 1 – Cronometragem exclusivamente da ordenação e comparação com a referência Java:')
for line in [
    'int[] copy = original.clone();',
    'long start = System.nanoTime();',
    'if (mode == 0) SortingAlgorithms.serial(alg, copy);',
    'else SortingAlgorithms.parallel(alg, copy, mode, pool);',
    'long elapsed = System.nanoTime() - start;',
    'if (!Arrays.equals(copy, expected)) throw new AssertionError();',
]:
    v=d.add_paragraph(style='Normal');v.paragraph_format.line_spacing=1.0;v.paragraph_format.space_after=Pt(0);v.paragraph_format.first_line_indent=Cm(.35)
    t=v.add_run(line);t.font.name='Consolas';t.font.size=Pt(8.7)
p('Trecho 2 – Gerenciamento das subtarefas no Merge Sort paralelo:')
for line in [
    'int mid = (lo + hi) >>> 1;',
    'invokeAll(new MergeTask(a, tmp, lo, mid),',
    '          new MergeTask(a, tmp, mid, hi));',
    'mergeRanges(a, tmp, lo, mid, hi);',
]:
    v=d.add_paragraph(style='Normal');v.paragraph_format.line_spacing=1.0;v.paragraph_format.space_after=Pt(0);v.paragraph_format.first_line_indent=Cm(.35)
    t=v.add_run(line);t.font.name='Consolas';t.font.size=Pt(8.7)
p('Trecho 3 – Definição do speedup e da eficiência na análise estatística:')
for line in [
    'speedup = ref / median',
    'efficiency = speedup / threads',
]:
    v=d.add_paragraph(style='Normal');v.paragraph_format.line_spacing=1.0;v.paragraph_format.space_after=Pt(0);v.paragraph_format.first_line_indent=Cm(.35)
    t=v.add_run(line);t.font.name='Consolas';t.font.size=Pt(8.7)


# Rodape pagina automatica.
footer=section.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
run=footer.add_run('UNIFOR • Ciência da Computação   |   Página ');run.font.size=Pt(8);run.font.color.rgb=RGBColor(110,110,110)
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)

# propriedade autor propositalmente generica
meta=d.core_properties;meta.title='Análise de Desempenho de Algoritmos de Ordenação em Java';meta.author='Equipe da disciplina de Ciência da Computação';meta.subject='Relatório acadêmico de programação paralela e concorrente'
d.save(TARGET)
print(TARGET)
