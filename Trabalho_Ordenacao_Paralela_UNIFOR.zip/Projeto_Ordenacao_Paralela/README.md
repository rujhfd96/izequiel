# Estudo comparativo de algoritmos de ordenação seriais e paralelos em Java

Projeto acadêmico para **Ciência da Computação — Universidade de Fortaleza (UNIFOR)**.

> **Correção do enunciado:** Bubble, Quick, Merge, Selection, Counting e Insertion Sort são algoritmos de **ordenação**, não de busca. O projeto estuda quatro dentre os seis listados.

## Entregáveis

- `src/SortingAlgorithms.java`: Quick Sort, Merge Sort, Counting Sort e Insertion Sort, cada um em uma modalidade sequencial e uma modalidade paralela. O *Insertion Sort paralelo é um algoritmo híbrido* (Insertion Sort em partições seguido de intercalação); seus ganhos não decorrem exclusivamente do paralelismo.
- `src/ExperimentRunner.java`: execução, cronometração, geração reprodutível de dados, validação, aquecimento JVM, 5 amostras, gravação de CSV.
- `src/SelfTest.java`: testes de correção, casos-limite e comparação com `Arrays.sort`.
- `src/ChartViewer.java`: **gráfico dinâmico em Java Swing** com menus de algoritmo, entrada e CPUs disponíveis (extra solicitado).
- `scripts/analyze.py`: análise com mediana, média, desvio-padrão, coeficiente de variação, speedup e eficiência; gera gráficos PNG.
- `scripts/run_linux.sh`: usa `taskset` para controlar **afinidade real das CPUs** em Linux.
- `scripts/run_windows.ps1`: limita o número de processadores visível à JVM, mas **não controla afinidade real** no Windows.
- `resultados/resultados_brutos.csv`: 4.320 amostras executadas no ambiente de testes, 5 por configuração.
- `resultados/resumo_estatistico.csv`: 864 grupos estatísticos.
- `graficos/`: sete gráficos PNG, um por algoritmo e três comparativos.
- `Relatorio_Ordenacao_Paralela_UNIFOR.docx`: artigo conforme o modelo da disciplina.

## Requisitos

- Java JDK 17+ (testado com OpenJDK 21).
- Python 3 com `matplotlib` para gerar os PNGs (`python -m pip install matplotlib`).
- `taskset` e Linux para reproduzir limitação efetiva de CPUs. No Windows, há script alternativo (contagem lógica somente).
- Não são necessários Maven nem outras bibliotecas Java.

## Executar no Linux

```bash
chmod +x scripts/run_linux.sh
./scripts/run_linux.sh
java -cp build ChartViewer resultados/resumo_estatistico.csv
```

O script recompila, executa testes de correção, mede com 1, 2 e 4 CPUs disponíveis, exporta CSVs e gráficos. Caso o computador não permita 4 CPUs, utiliza apenas as configurações suportadas. **Observação:** as execuções completas podem levar alguns minutos. O script remove o CSV anterior para não misturar experimentos.

Exemplo de execução menor, sempre com 5 amostras:

```bash
SIZES=2000,10000 INSERTION_SIZES=2000,5000 WARMUPS=2 ./scripts/run_linux.sh
```

## Executar no Windows (PowerShell)

```powershell
javac -encoding UTF-8 -d build src/*.java
java -ea -cp build SelfTest
powershell -ExecutionPolicy Bypass -File scripts/run_windows.ps1
java -cp build ChartViewer resultados/resumo_estatistico.csv
```

Se estiver usando VS Code/IntelliJ, execute o `SelfTest` e depois o `ExperimentRunner` com os parâmetros desejados. `run_windows.ps1` emprega `-XX:ActiveProcessorCount` e não impõe afinidade física; não se deve apresentar seus números como testes com núcleos *realmente reservados*. Para aferição de afinidade real, use Linux/WSL2 com `taskset` (observadas as restrições de virtualização).

### Exemplo manual de benchmark

```bash
javac -d build src/*.java
java -cp build ExperimentRunner --out resultados/meu.csv --cores 4 --strict-cores false --threads 1,2,4 --reps 5 --warmups 3 --sizes 2000,10000,30000 --insertion-sizes 2000,10000
python3 scripts/analyze.py resultados/meu.csv resultados/meu_resumo.csv graficos_customizados
```

Sem `taskset`, `--strict-cores false` é útil para experimentar, mas a coluna `cores_configured` passa a ser apenas um rótulo: não equivale à limitação do hardware.

## Desenho experimental

- Algoritmos: `quick`, `merge`, `counting`, `insertion`.
- Natureza das entradas: `random`, `sorted`, `reversed` e `few_unique`.
- Tamanhos: 2.000 / 10.000 / 30.000 / 100.000 / 300.000 (Quick, Merge, Counting) e 2.000 / 10.000 / 20.000 (Insertion).
- CPUs Linux permitidas: 1, 2, 4 (via afinidade do processo); todas as opções testam modo serial e 1/2/4 threads no modo paralelo.
- 5 medições por configuração (mínimo pedido); aquecimentos de 2–3 por configuração nos arquivos incluídos; o script de reprodução usa 3 por padrão.
- Mesma semente e a mesma distribuição para todas as implementações com tamanho/distribuição iguais.
- `System.nanoTime()` mede **somente a execução da ordenação**: clonagem, verificação e geração de entradas ficam fora do intervalo medido. Alocações internas do algoritmo estão incluídas no tempo.
- Uma nova instância de `ForkJoinPool(p)` é preparada e reutilizada para cada contagem de threads, fora da cronometragem; a criação das tarefas acontece dentro da medição.
- Validação por comparação elemento a elemento com `Arrays.sort`, e nenhuma linha é gravada caso uma ordenação falhe.

### Colunas do CSV bruto

`timestamp_utc,jdk,os,available_processors,cores_configured,algorithm,distribution,size,mode,threads,trial,elapsed_ns,elapsed_ms,seed,valid`

Em `mode=serial`, `threads=0` é um código de modalidade, **não significa que nenhuma thread Java execute a ordenação** (uma thread principal é utilizada).

### Cálculos estatísticos

`speedup = mediana_tempo_serial / mediana_tempo_paralelo`

`eficiencia = speedup / threads`

`cv_percent = 100 * desvio_padrao_amostral / media`

Speedup pode exceder o número de threads quando o algoritmo paralelo faz **menos trabalho algorítmico**, como no Insertion híbrido; isso não indica escalonamento ideal do mesmo algoritmo.

## Como apresentar

1. Explique o problema e os quatro algoritmos; destaque a complexidade e o limite do Counting Sort (`max-min+1 <= 5.000.000`).
2. Mostre `SortingAlgorithms.java` e `SelfTest.java`; execute `java -cp build SelfTest`.
3. Explique as quatro distribuições, os tamanhos, a quantidade de repetições e a mediana.
4. Abra `ChartViewer` e alterne os filtros na frente da turma.
5. Destaque o caso `n = 300.000`, aleatório, CPUs = 4: Quick 2,42×, Merge 2,81× e Counting 0,65× com quatro threads; Insertion `n = 20.000` chega a 6,44× **por ser híbrido**.
6. Finalize com custos de coordenação, gargalos, vantagens de cada algoritmo e limitações do ambiente de avaliação.

## Publicação no GitHub (exigida no artigo)

Um endereço de repositório **não pode ser criado apenas gerando arquivos locais**. Para publicar, crie um repositório no seu GitHub e execute:

```bash
git init
git add .
git commit -m "Projeto de ordenacao sequencial e paralela em Java"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/NOME_DO_REPOSITORIO.git
git push -u origin main
```

Substitua o URL de exemplo pelo URL **real** do repositório criado e, antes da entrega, preencha o campo **“Anexos – Link do GitHub”** no artigo. **Não foi criado nem publicado um repositório pelo assistente.** Evite divulgar nomes completos dos autores antes de confirmá-los.

## Limitações e honestidade metodológica

Os números anexos foram medidos em um ambiente Linux de execução compartilhada, com OpenJDK 21, afinidade Linux de 1, 2 ou 4 CPUs lógicas e uma cota de CPU do contêiner. Os resultados **não representam necessariamente** um notebook, estação local ou infraestrutura de produção. O experimento não usa JMH e não registra consumo energético/uso máximo de memória. Em experimentos adicionais, recomenda-se controlar turbo boost, aquecimento, compilação JIT, coleta de lixo e variação de carga externa.

## Fontes

- NIST DADS: https://doi.org/10.6028/NIST.IR.8318
- Oracle `System.nanoTime`: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/System.html
- Oracle `ForkJoinPool`: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/ForkJoinPool.html
- OpenJDK JMH: https://github.com/openjdk/jmh
