# Windows: contagem logica de processadores simulada para a JVM.
# ATENCAO: -XX:ActiveProcessorCount nao fixa afinidade real dos processadores.
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
New-Item -Force -ItemType Directory build, resultados, graficos | Out-Null
javac -encoding UTF-8 -d build src/*.java
if ($LASTEXITCODE -ne 0) { throw 'Falha na compilacao' }
java -ea -cp build SelfTest
if ($LASTEXITCODE -ne 0) { throw 'Falha nos testes' }
$csv = 'resultados/resultados_brutos.csv'
if (Test-Path $csv) { Remove-Item $csv }
foreach ($cores in @(1, 2, 4)) {
  Write-Host "JVM com ActiveProcessorCount=$cores (simulacao de visibilidade; nao fixa afinidade)"
  java "-XX:ActiveProcessorCount=$cores" -Xms256m -Xmx2g -cp build ExperimentRunner --out $csv --cores $cores --threads '1,2,4' --reps 5 --warmups 3 --strict-cores true
  if ($LASTEXITCODE -ne 0) { throw 'Falha no experimento' }
}
python scripts/analyze.py $csv resultados/resumo_estatistico.csv graficos
if ($LASTEXITCODE -ne 0) { throw 'Falha na analise (verificar matplotlib)' }
