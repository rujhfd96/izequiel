import java.util.*;
import java.util.concurrent.ForkJoinPool;

public class SelfTest {
    public static void main(String[] args) {
        int[][] cases = { {}, {3}, {1,1,1,1}, {0,-1,-5,0,100,12}, {4,3,2,1}, {1,2,3,4},
             {Integer.MIN_VALUE,0,Integer.MAX_VALUE} };
        for(String alg: new String[]{"quick","merge","insertion","counting"}) {
            for(int[] sample:cases) {
                if(alg.equals("counting") && sample.length>0 &&
                        (long)Arrays.stream(sample).max().getAsInt()-Arrays.stream(sample).min().getAsInt()+1>5_000_000)continue;
                int[] expected=sample.clone(); Arrays.sort(expected);
                int[] actual=sample.clone(); SortingAlgorithms.serial(alg,actual);
                if(!Arrays.equals(expected,actual)) throw new AssertionError("serial "+alg);
                for(int p:new int[]{1,2,4}) {
                    try(ForkJoinPool pool=new ForkJoinPool(p)) {
                        actual=sample.clone();SortingAlgorithms.parallel(alg,actual,p,pool);
                        if(!Arrays.equals(expected,actual))throw new AssertionError("parallel "+alg+" "+p);
                    }
                }
            }
            for(int n:new int[]{2,17,100,2000,20000}) for(String shape:new String[]{"random","sorted","reversed","few_unique"}) {
                int[] sample=ExperimentRunner.data(n,shape,314159);
                int[] expected=sample.clone();Arrays.sort(expected);
                int[] actual=sample.clone();SortingAlgorithms.serial(alg,actual);
                if(!Arrays.equals(expected,actual))throw new AssertionError(alg+" serial n="+n+" "+shape);
                for(int p:new int[]{1,2,4}) {
                    try(ForkJoinPool pool=new ForkJoinPool(p)) {
                        actual=sample.clone();SortingAlgorithms.parallel(alg,actual,p,pool);
                        if(!Arrays.equals(expected,actual))throw new AssertionError(alg+" parallel n="+n+" "+shape+" p="+p);
                    }
                }
            }
        }
        System.out.println("OK: 4 algoritmos, casos-limite, 5 tamanhos, 4 distribuicoes, 3 configuracoes de threads.");
    }
}
