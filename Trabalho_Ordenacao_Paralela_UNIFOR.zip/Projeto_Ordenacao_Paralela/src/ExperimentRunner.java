import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ForkJoinPool;

/** Benchmark reprodutivel: CSV bruto com uma linha por amostra validada. */
public final class ExperimentRunner {
    private static final String HEADER = "timestamp_utc,jdk,os,available_processors,cores_configured,algorithm,distribution,size,mode,threads,trial,elapsed_ns,elapsed_ms,seed,valid";
    private static final String[] ALGORITHMS = {"quick", "merge", "counting", "insertion"};
    private static final String[] DISTRIBUTIONS = {"random", "sorted", "reversed", "few_unique"};

    public static void main(String[] args) throws Exception {
        Map<String,String> opt = parse(args);
        Path out=Path.of(opt.getOrDefault("out", "resultados/resultados_brutos.csv"));
        int cores=Integer.parseInt(opt.getOrDefault("cores", "1"));
        int[] threadOptions=numbers(opt.getOrDefault("threads", "1,2,4"));
        int[] fastSizes=numbers(opt.getOrDefault("sizes", "2000,10000,30000,100000,300000"));
        int[] slowSizes=numbers(opt.getOrDefault("insertion-sizes", "2000,10000,20000"));
        int reps=Integer.parseInt(opt.getOrDefault("reps", "5"));
        int warmups=Integer.parseInt(opt.getOrDefault("warmups", "3"));
        if(reps<5) throw new IllegalArgumentException("Ao menos 5 amostras por configuracao");
        if(cores < 1 || warmups < 0) throw new IllegalArgumentException("Parametros invalidos");
        if(Boolean.parseBoolean(opt.getOrDefault("strict-cores", "true")) &&
           Runtime.getRuntime().availableProcessors()!=cores)
            throw new IllegalStateException("Afinidade/cores nao conferem: esperado " + cores + ", JVM detectou " + Runtime.getRuntime().availableProcessors());
        Files.createDirectories(out.toAbsolutePath().getParent());
        boolean needsHeader=!Files.exists(out) || Files.size(out)==0;
        Map<Integer,ForkJoinPool> pools=new LinkedHashMap<>();
        for(int threads : threadOptions) {
            if(threads<1) throw new IllegalArgumentException("threads deve ser positivo");
            pools.put(threads, new ForkJoinPool(threads));
        }
        long records=0;
        try (BufferedWriter writer=Files.newBufferedWriter(out, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            if(needsHeader) {writer.write(HEADER);writer.newLine();}
            for(String alg:opt.getOrDefault("algorithms", String.join(",", ALGORITHMS)).split(",")) {
                for(int n : (alg.equals("insertion") ? slowSizes:fastSizes)) {
                    for(String distribution:opt.getOrDefault("distributions", String.join(",", DISTRIBUTIONS)).split(",")) {
                        long seed=0x3AD0_2026L + 31L*n + 97L*Arrays.asList(DISTRIBUTIONS).indexOf(distribution);
                        int[] original=data(n,distribution,seed);
                        int[] expected=original.clone(); Arrays.sort(expected);
                        List<Integer> modes=new ArrayList<>(); modes.add(0); // zero=serial
                        for(int t:threadOptions) modes.add(t);
                        // Alterna a ordem dos modos entre instancias; minimiza vies sistematico de aquecimento.
                        if ((n/1000)%2 == 0) Collections.reverse(modes);
                        for (int mode:modes) {
                            String label=mode==0 ? "serial":"parallel";
                            ForkJoinPool pool=mode==0?null:pools.get(mode);
                            for(int warm=0;warm<warmups;warm++) {
                                int[] copy=original.clone();
                                if(mode==0) SortingAlgorithms.serial(alg,copy);
                                else SortingAlgorithms.parallel(alg,copy,mode,pool);
                                if(!Arrays.equals(copy,expected)) throw new AssertionError("Warmup incorreto: " + alg + "/" + distribution);
                            }
                            for(int trial=1;trial<=reps;trial++) {
                                int[] copy=original.clone(); // Clone fora do cronometro.
                                long start=System.nanoTime();
                                if(mode==0) SortingAlgorithms.serial(alg,copy);
                                else SortingAlgorithms.parallel(alg,copy,mode,pool);
                                long elapsed=System.nanoTime()-start;
                                if(!Arrays.equals(copy,expected)) throw new AssertionError("Resultado incorreto: " + alg + "/" + distribution);
                                writer.write(String.join(",",Instant.now().toString(),csv(System.getProperty("java.version")),
                                      csv(System.getProperty("os.name")),""+Runtime.getRuntime().availableProcessors(),
                                      ""+cores,alg,distribution,""+n,label,""+mode,""+trial,""+elapsed,
                                      String.format(Locale.US,"%.6f",elapsed/1e6),""+seed,"true"));
                                writer.newLine(); records++;
                            }
                            writer.flush();
                        }
                        System.out.printf(Locale.US,"core=%d alg=%s n=%d entrada=%s concluido%n",cores,alg,n,distribution);
                    }
                }
            }
        } finally {for(ForkJoinPool p:pools.values())p.shutdown();}
        System.out.println("Amostras geradas: "+records+" em "+out);
    }

    public static int[] data(int size,String dist,long seed) {
        Random rng=new Random(seed);int[] a=new int[size];
        for(int i=0;i<size;i++) a[i]=rng.nextInt(Math.max(1,size));
        switch(dist) {
            case "random" -> { }
            case "sorted" -> Arrays.sort(a);
            case "reversed" -> {Arrays.sort(a);for(int i=0;i<size/2;i++){int j=size-1-i;int v=a[i];a[i]=a[j];a[j]=v;}}
            case "few_unique" -> {for(int i=0;i<size;i++)a[i]=rng.nextInt(16);}
            default -> throw new IllegalArgumentException("Distribuicao desconhecida: "+dist);
        }
        return a;
    }
    private static Map<String,String> parse(String[] args) {
        Map<String,String> m=new HashMap<>();
        for(int i=0;i<args.length;i+=2) {
            if(!args[i].startsWith("--") || i+1>=args.length) throw new IllegalArgumentException("Uso: --opcao valor");
            m.put(args[i].substring(2),args[i+1]);
        }
        return m;
    }
    private static int[] numbers(String s) {return Arrays.stream(s.split(",")).mapToInt(x->Integer.parseInt(x.trim())).toArray();}
    private static String csv(String s) {return '"'+s.replace("\"","\"\"")+'"';}
}
