import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

/** Quatro algoritmos com implementacoes sequenciais e concorrentes, sem dependencias externas. */
public final class SortingAlgorithms {
    private SortingAlgorithms() {}
    private static final int INSERTION_CUTOFF = 32;
    private static final int PARALLEL_THRESHOLD = 16_384;

    public static void serial(String name, int[] data) {
        switch (name) {
            case "quick" -> quick(data, 0, data.length - 1);
            case "merge" -> merge(data, new int[data.length], 0, data.length);
            case "counting" -> counting(data);
            case "insertion" -> insertion(data, 0, data.length);
            default -> throw new IllegalArgumentException("Algoritmo invalido: " + name);
        }
    }

    public static void parallel(String name, int[] data, int threads, ForkJoinPool pool) {
        if (threads < 1 || pool == null || pool.getParallelism() != threads)
            throw new IllegalArgumentException("Pool deve possuir paralelismo igual a threads");
        switch (name) {
            case "quick" -> pool.invoke(new QuickTask(data, 0, data.length - 1));
            case "merge" -> pool.invoke(new MergeTask(data, new int[data.length], 0, data.length));
            case "counting" -> countingParallel(data, threads, pool);
            case "insertion" -> insertionParallelHybrid(data, threads, pool);
            default -> throw new IllegalArgumentException("Algoritmo invalido: " + name);
        }
    }

    private static void insertion(int[] a, int lo, int hi) {
        for (int i = lo + 1; i < hi; i++) {
            int value = a[i], j = i - 1;
            while (j >= lo && a[j] > value) { a[j + 1] = a[j]; j--; }
            a[j + 1] = value;
        }
    }

    private static int median(int a, int b, int c) {
        return a < b ? (b < c ? b : (a < c ? c : a)) : (a < c ? a : (b < c ? c : b));
    }

    // Quicksort com particao em tres vias, evitando casos patologicos com repetidos.
    private static void quick(int[] a, int lo, int hi) {
        while (lo < hi) {
            if (hi - lo < INSERTION_CUTOFF) { insertion(a, lo, hi + 1); return; }
            int pivot = median(a[lo], a[lo + ((hi - lo) >>> 1)], a[hi]);
            int lt = lo, i = lo, gt = hi;
            while (i <= gt) {
                if (a[i] < pivot) swap(a, lt++, i++);
                else if (a[i] > pivot) swap(a, i, gt--);
                else i++;
            }
            // Processar o lado menor primeiro limita a profundidade de pilha.
            if (lt - lo < hi - gt) { quick(a, lo, lt - 1); lo = gt + 1; }
            else { quick(a, gt + 1, hi); hi = lt - 1; }
        }
    }

    private static void swap(int[] a, int i, int j) {
        int tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }

    private static class QuickTask extends RecursiveAction {
        private final int[] a; private final int lo, hi;
        QuickTask(int[] a, int lo, int hi) { this.a=a; this.lo=lo; this.hi=hi; }
        @Override protected void compute() {
            if (hi - lo + 1 <= PARALLEL_THRESHOLD) { quick(a, lo, hi); return; }
            int pivot = median(a[lo], a[lo + ((hi - lo) >>> 1)], a[hi]);
            int lt = lo, i = lo, gt = hi;
            while (i <= gt) {
                if (a[i] < pivot) swap(a, lt++, i++);
                else if (a[i] > pivot) swap(a, i, gt--);
                else i++;
            }
            QuickTask left = new QuickTask(a, lo, lt - 1);
            QuickTask right = new QuickTask(a, gt + 1, hi);
            if (lt - lo < hi - gt) { right.fork(); left.compute(); right.join(); }
            else { left.fork(); right.compute(); left.join(); }
        }
    }

    private static void merge(int[] a, int[] tmp, int lo, int hi) {
        if (hi - lo <= 1) return;
        int mid = (lo + hi) >>> 1;
        merge(a, tmp, lo, mid); merge(a, tmp, mid, hi);
        mergeRanges(a, tmp, lo, mid, hi);
    }

    private static void mergeRanges(int[] a, int[] tmp, int lo, int mid, int hi) {
        if (a[mid - 1] <= a[mid]) return;
        int i=lo, j=mid, k=lo;
        while (i < mid && j < hi) tmp[k++] = a[i] <= a[j] ? a[i++] : a[j++];
        while (i < mid) tmp[k++] = a[i++];
        while (j < hi) tmp[k++] = a[j++];
        System.arraycopy(tmp, lo, a, lo, hi-lo);
    }

    private static class MergeTask extends RecursiveAction {
        private final int[] a, tmp; private final int lo, hi;
        MergeTask(int[] a, int[] tmp, int lo, int hi) {this.a=a;this.tmp=tmp;this.lo=lo;this.hi=hi;}
        @Override protected void compute() {
            if (hi - lo <= PARALLEL_THRESHOLD) { merge(a, tmp, lo, hi); return; }
            int mid = (lo + hi) >>> 1;
            invokeAll(new MergeTask(a, tmp, lo, mid), new MergeTask(a, tmp, mid, hi));
            mergeRanges(a, tmp, lo, mid, hi);
        }
    }

    private static int[] bounds(int[] a) {
        if (a.length == 0) return new int[]{0, -1};
        int lo=a[0], hi=a[0];
        for (int v : a) {if (v<lo) lo=v; if(v>hi) hi=v;}
        if ((long)hi - lo + 1 > 5_000_000)
            throw new IllegalArgumentException("Counting Sort exige intervalo <= 5.000.000");
        return new int[]{lo, hi};
    }
    private static void counting(int[] a) {
        if (a.length == 0) return;
        int[] mm=bounds(a); int min=mm[0];
        int[] counts=new int[(int)((long)mm[1]-min+1)];
        for(int v:a) counts[v-min]++;
        int j=0;
        for(int b=0;b<counts.length;b++) for(int q=0;q<counts[b];q++) a[j++]=b+min;
    }
    private static void countingParallel(int[] a, int threads, ForkJoinPool pool) {
        if (a.length == 0) return;
        int[] mm=bounds(a); int min=mm[0], range=(int)((long)mm[1]-min+1);
        // Um histograma privado por tarefa: evita contenção e falsos compartilhamentos nos incrementos.
        int workers=Math.min(threads, a.length); int[][] hist=new int[workers][range];
        java.util.List<RecursiveAction> tasks=new java.util.ArrayList<>();
        for (int w=0;w<workers;w++) {
            final int id=w, from=(int)((long)w*a.length/workers), to=(int)((long)(w+1)*a.length/workers);
            tasks.add(new RecursiveAction() { @Override protected void compute() {
                for(int i=from;i<to;i++) hist[id][a[i]-min]++;
            }});
        }
        pool.submit(() -> java.util.concurrent.ForkJoinTask.invokeAll(tasks)).join();
        int[] counts=new int[range];
        for(int w=0;w<workers;w++) for(int b=0;b<range;b++) counts[b]+=hist[w][b];
        // Escrita de saida intencionalmente serial: identifica limite de escalabilidade.
        int j=0;
        for(int b=0;b<range;b++) for(int q=0;q<counts[b];q++) a[j++]=b+min;
    }

    // Versao hibrida: insertion sort puro dentro de cada particao, merge na reducao final.
    private static void insertionParallelHybrid(int[] a, int threads, ForkJoinPool pool) {
        if (a.length <= 1) return;
        int p=Math.min(threads, a.length), n=a.length;
        int[] boundaries=new int[p+1];
        for(int i=0;i<=p;i++) boundaries[i]=(int)((long)i*n/p);
        java.util.List<RecursiveAction> tasks=new java.util.ArrayList<>();
        for(int w=0;w<p;w++) {
            final int lo=boundaries[w], hi=boundaries[w+1];
            tasks.add(new RecursiveAction() { @Override protected void compute() { insertion(a, lo, hi); }});
        }
        pool.submit(() -> java.util.concurrent.ForkJoinTask.invokeAll(tasks)).join();
        int[] tmp=new int[n];
        int[] intervals=boundaries;
        while(intervals.length > 2) {
            int chunkCount=intervals.length-1;
            int merged=(chunkCount+1)/2;
            int[] next=new int[merged+1];
            next[0]=intervals[0];
            java.util.List<RecursiveAction> mergeTasks=new java.util.ArrayList<>();
            for(int pair=0;pair<merged;pair++) {
                int left=2*pair, lo=intervals[left], mid=intervals[left+1];
                final int hi=(left+2<=chunkCount) ? intervals[left+2] : mid;
                if(hi>mid) mergeTasks.add(new RecursiveAction(){@Override protected void compute(){mergeRanges(a,tmp,lo,mid,hi);}});
                next[pair+1]=hi;
            }
            pool.submit(() -> java.util.concurrent.ForkJoinTask.invokeAll(mergeTasks)).join();
            intervals=next;
        }
    }
}
