#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build resultados graficos
javac -encoding UTF-8 -d build src/*.java
java -ea -cp build SelfTest
# Afinidade real de CPU: cada JVM so pode executar nos nucleos explicitamente listados.
mapfile -t CPUS < <(python3 -c 'import os; print("\n".join(str(i) for i in sorted(os.sched_getaffinity(0))))')
MAX_CORES=${MAX_CORES:-4}
OUT="resultados/resultados_brutos.csv"
rm -f "$OUT"
for CORES in 1 2 4; do
    if (( CORES > ${#CPUS[@]} || CORES > MAX_CORES )); then continue; fi
    ALLOWED=$(IFS=,; echo "${CPUS[*]:0:CORES}")
    echo "===> Cores autorizados: ${ALLOWED}, threads: 1,2,4"
    taskset -c "$ALLOWED" java -Xms256m -Xmx2g -cp build ExperimentRunner \
       --out "$OUT" --cores "$CORES" --threads "1,2,4" --reps "${REPS:-5}" \
       --warmups "${WARMUPS:-3}" --sizes "${SIZES:-2000,10000,30000,100000,300000}" \
       --insertion-sizes "${INSERTION_SIZES:-2000,10000,20000}" --strict-cores true
 done
python3 scripts/analyze.py "$OUT" resultados/resumo_estatistico.csv graficos
printf '\nBenchmark completo. CSVs em resultados/; graficos em graficos/.\n'
