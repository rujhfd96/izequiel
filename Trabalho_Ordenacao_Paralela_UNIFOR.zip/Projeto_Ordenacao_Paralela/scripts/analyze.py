#!/usr/bin/env python3
"""Resumo estatistico e PNGs; CSV com modulo padrao, graficos com matplotlib."""
import csv
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

SRC=Path(sys.argv[1] if len(sys.argv)>1 else 'resultados/resultados_brutos.csv')
DEST=Path(sys.argv[2] if len(sys.argv)>2 else 'resultados/resumo_estatistico.csv')
FIGDIR=Path(sys.argv[3] if len(sys.argv)>3 else 'graficos')
FIGDIR.mkdir(parents=True, exist_ok=True)

with SRC.open(encoding='utf-8', newline='') as f:
    raw=list(csv.DictReader(f))
if not raw: raise SystemExit('Nenhuma observacao no arquivo de entrada')
if not all(r['valid']=='true' for r in raw): raise SystemExit('Ha amostras invalidas')
groups=defaultdict(list)
for r in raw:
    key=(int(r['cores_configured']),r['algorithm'],r['distribution'],int(r['size']),r['mode'],int(r['threads']))
    groups[key].append(int(r['elapsed_ns'])/1e6)

baselines={key[:4]:statistics.median(samples) for key,samples in groups.items() if key[4]=='serial'}
header=['cores','algorithm','distribution','size','mode','threads','samples','mean_ms','median_ms','std_ms','min_ms','max_ms','speedup_vs_serial','efficiency_vs_threads','cv_percent']
rows=[]
for key,samples in sorted(groups.items()):
    core,alg,dist,n,mode,threads=key
    median=statistics.median(samples)
    ref=baselines[key[:4]]
    speedup=ref/median if median else float('nan')
    row=dict(zip(header,[core,alg,dist,n,mode,threads,len(samples),
         round(statistics.mean(samples),6),round(median,6),
         round(statistics.stdev(samples),6) if len(samples)>1 else 0,
         round(min(samples),6),round(max(samples),6),round(speedup,4),
         round(speedup/threads,4) if mode=='parallel' else '',
         round(statistics.stdev(samples)/statistics.mean(samples)*100,2) if len(samples)>1 and statistics.mean(samples)!=0 else 0]))
    rows.append(row)
DEST.parent.mkdir(parents=True,exist_ok=True)
with DEST.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=header);w.writeheader();w.writerows(rows)
print(f'{len(raw)} amostras, {len(rows)} grupos; salvo: {DEST}')

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
except ImportError:
    print('matplotlib nao instalado; CSVs disponiveis; graficos PNG requerem pip install matplotlib')
    sys.exit(0)

cores_available=sorted(set(r['cores'] for r in rows))
chosen_core=max(cores_available)
for alg in ['quick','merge','counting','insertion']:
    subset=[r for r in rows if r['cores']==chosen_core and r['algorithm']==alg and r['distribution']=='random']
    fig,ax=plt.subplots(figsize=(9,5.3))
    modes=[('serial',0,'Sequencial'),('parallel',1,'Paralelo (1 thread)'),('parallel',2,'Paralelo (2 threads)'),('parallel',4,'Paralelo (4 threads)')]
    for mode,t,label in modes:
        pts=sorted((r['size'],r['median_ms']) for r in subset if r['mode']==mode and r['threads']==t)
        if pts:ax.plot([p[0] for p in pts],[p[1] for p in pts],marker='o',label=label)
    ax.set_title(f'{alg.title()} • entrada aleatoria • {chosen_core} CPUs permitidas')
    ax.set_xlabel('Tamanho do vetor (elementos)')
    ax.set_ylabel('Tempo mediano (ms)')
    ax.set_ylim(bottom=0);ax.grid(alpha=.22);ax.legend(fontsize=9)
    fig.tight_layout();fig.savefig(FIGDIR/f'tempos_{alg}.png',dpi=165);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,5.3))
for alg in ['quick','merge','counting','insertion']:
    available=[r for r in rows if r['cores']==chosen_core and r['algorithm']==alg and r['distribution']=='random' and r['mode']=='parallel' and r['threads']==4]
    if not available:continue
    largest=max(r['size'] for r in available)
    pts=sorted((r['threads'],r['speedup_vs_serial']) for r in rows if r['cores']==chosen_core and r['algorithm']==alg and r['distribution']=='random' and r['size']==largest and r['mode']=='parallel')
    if pts:ax.plot([x for x,y in pts],[y for x,y in pts],marker='o',label=f'{alg} (n={largest})')
ax.plot([1,2,4],[1,2,4],'--',label='Ideal (S = p)',linewidth=1.1)
ax.set_xticks([1,2,4]);ax.set_xlabel('Threads');ax.set_ylabel('Speedup = mediana serial / mediana paralela')
ax.set_title(f'Escalabilidade • entrada aleatoria • {chosen_core} CPUs permitidas')
ax.grid(alpha=.22);ax.legend(fontsize=9)
fig.tight_layout();fig.savefig(FIGDIR/'speedup_por_threads.png',dpi=165);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,5.3))
for alg in ['quick','merge','counting','insertion']:
    cand=[r for r in rows if r['algorithm']==alg and r['distribution']=='random' and r['mode']=='parallel' and r['threads']==4]
    if not cand:continue
    n=max(r['size'] for r in cand)
    pts=sorted((r['cores'],r['median_ms']) for r in cand if r['size']==n)
    if pts:ax.plot([x for x,y in pts],[y for x,y in pts],marker='o',label=f'{alg} (n={n})')
ax.set_xticks(cores_available);ax.set_xlabel('CPUs logicas permitidas (afinidade Linux)')
ax.set_ylabel('Tempo mediano (ms)');ax.set_title('Efeito do numero de CPUs disponiveis • 4 threads')
ax.set_ylim(bottom=0);ax.grid(alpha=.22);ax.legend(fontsize=9)
fig.tight_layout();fig.savefig(FIGDIR/'cores_disponiveis.png',dpi=165);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,5.3))
for alg in ['quick','merge','counting','insertion']:
    candidate=[r for r in rows if r['cores']==chosen_core and r['algorithm']==alg and r['distribution']=='random' and r['mode']=='serial']
    n=max(r['size'] for r in candidate)
    pts=[]
    for dist in ['random','sorted','reversed','few_unique']:
        r=next((x for x in rows if x['cores']==chosen_core and x['algorithm']==alg and x['distribution']==dist and x['mode']=='serial' and x['size']==n),None)
        if r:pts.append((dist,r['median_ms']))
    xs=range(len(pts))
    ax.plot(list(xs),[y for _,y in pts],marker='o',label=f'{alg} (n={n})')
ax.set_xticks(range(4),['Aleatorio','Ordenado','Invertido','Poucos distintos'])
ax.set_ylabel('Mediana sequencial (ms)');ax.set_title(f'Impacto da distribuicao • {chosen_core} CPUs')
ax.set_ylim(bottom=0);ax.grid(alpha=.22);ax.legend(fontsize=9)
fig.tight_layout();fig.savefig(FIGDIR/'distribuicoes.png',dpi=165);plt.close(fig)
print(f'7 graficos em {FIGDIR}')
